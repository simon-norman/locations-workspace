export const defaultValidation = { minLength: 1, maxLength: 100 };
