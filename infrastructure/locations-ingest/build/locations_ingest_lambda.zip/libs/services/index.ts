export const foo = () => {
	console.log("HEALTH");
	return "bar";
};
